#include <iostream>
using namespace std;

class Node {
public:
    int data;
    Node *left;
    Node *right;

    Node(int value = 0) : data(value), left(nullptr), right(nullptr) {
    	
	}
};

class Tree {
public:
    Node *root;

    Tree() : root(nullptr) {}

    void setRoot(Node* node) {
        root = node;
    }

    void traversePreOrder(Node *temp) {
        if (temp) {
            cout << temp->data << endl;
            traversePreOrder(temp->left);
            traversePreOrder(temp->right);
        }
    }

    void traverseInOrder(Node *temp) {
        if (temp) {
            traverseInOrder(temp->left);
            cout << temp->data << endl;
            traverseInOrder(temp->right);
        }
    }

    void traversePostOrder(Node *temp) {
        if (temp) {
            traversePostOrder(temp->left);
            traversePostOrder(temp->right);
            cout << temp->data << endl;
        }
    }
};

int main() {
    Node *n1 = new Node(12);
    Node *n2 = new Node(22);
    Node *n3 = new Node(7);
    Node *n4 = new Node(18);
    Node *n5 = new Node(24);
    Node *n6 = new Node(14);
    Node *n7 = new Node(20);
    Node *n8 = new Node(30);
    Node *n9 = new Node(10);
    Node *n10 = new Node(9);
    Node *n11 = new Node(3);

    // Building tree structure
    n1->left = n3;
    n1->right = n2;

    n2->left = n4;
    n2->right = n5;

    n4->left = n6;
    n4->right = n7;

    n5->right = n8;

    n3->left = n11;
    n3->right = n10;

    n10->right = n9;

    Tree t1;
    t1.setRoot(n1);  // Set root to our manually created root node

    cout << "Inorder:" << endl;
    t1.traverseInOrder(t1.root);

    cout << "Post-order:" << endl;
    t1.traversePostOrder(t1.root);

    cout << "Pre-order:" << endl;
    t1.traversePreOrder(t1.root);

    // Clean up memory (optional in simple example, recommended for larger programs)
    delete n1; delete n2; delete n3; delete n4; delete n5; delete n6; delete n7; delete n8; delete n9; delete n10; delete n11;

    return 0;
}
